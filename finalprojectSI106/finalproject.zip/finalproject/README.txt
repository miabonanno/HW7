ADD:
- Mia Bonanno
- 04832332
**Run the file chatbot_final.py**
1. Ask the chatbot: What’s the weather like in _(city name)_?
example: What’s the weather like in Ann Arbor?
example response: The weather in Ann Arbor is clear. 

2. Ask the chatbot: Is it going to rain in _(city name)_ today?
example: Is it going to rain in Tokyo today?
example response: It almost definitely will not rain in Tokyo today. 

3. Ask the chatbot: How hot will it get in _(city name)_ today?
example: How hot will it get in Greenwich today?
example response: In Greenwich it will reach 54.13 today.

4. Ask the chatbot: How cold will it get in _(city name)_ today?
example: How cold will it get in Greenwich today?
example response: In Greenwich it will get to 42.47.

5. Ask the chatbot: Is it going to rain in _(city name)_ this week?
example: Is it going to rain in Ann Arbor this week?

6. Ask the chatbot: How hot will it get in _(city name)_ this week?
example: How hot will it get in Detroit this week?

7. Ask the chatbot: How cold will it get in _(city name)_ this week?
example: How cold will it get in Seattle this week?

**To quit out of the chatbot: type “exit” into the terminal**




